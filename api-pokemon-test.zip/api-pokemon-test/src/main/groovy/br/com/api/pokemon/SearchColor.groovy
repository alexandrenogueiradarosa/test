package br.com.api.pokemon

import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient
import spock.lang.Specification
import spock.lang.Unroll


class SearchColor extends Specification{

    RESTClient client = new RESTClient('http://pokeapi.co/')

    def 'Consultar lista de cores'(){
        given:'Um recurso valido para listar as cores'
            def resource = '/api/v2/pokemon-color/'
        when:'chamar o servico'
            def response = client.get(path: resource)
            println(response.data)

        then:'retorna a lista com sucesso'
            response.status == 200
            with(response.data){
                count == 10
                previous == null
                next == null
                results != null
                results.size() == 10
                results[0].url == 'https://pokeapi.co/api/v2/pokemon-color/1/'
                results[0].name == 'black'
                results[1].url == 'https://pokeapi.co/api/v2/pokemon-color/2/'
                results[1].name == 'blue'
                results[2].url == 'https://pokeapi.co/api/v2/pokemon-color/3/'
                results[2].name == 'brown'
                results[3].url == 'https://pokeapi.co/api/v2/pokemon-color/4/'
                results[3].name == 'gray'
                results[4].url == 'https://pokeapi.co/api/v2/pokemon-color/5/'
                results[4].name == 'green'
                results[5].url == 'https://pokeapi.co/api/v2/pokemon-color/6/'
                results[5].name == 'pink'
                results[6].url == 'https://pokeapi.co/api/v2/pokemon-color/7/'
                results[6].name == 'purple'
                results[7].url == 'https://pokeapi.co/api/v2/pokemon-color/8/'
                results[7].name == 'red'
                results[8].url == 'https://pokeapi.co/api/v2/pokemon-color/9/'
                results[8].name == 'white'
                results[9].url == 'https://pokeapi.co/api/v2/pokemon-color/10/'
                results[9].name == 'yellow'
            }
    }

    @Unroll
    def 'Consultar cores por ID: consultar ID #id'(){
        given:'Um recurso valido com ID da cor'
            def resource = '/api/v2/pokemon-color/' + id
        when:'chamar o servico'
            def response = client.get(path: resource)
            println(response.data)

        then:'retorna as informacoes com sucesso'
            response.status == 200
            with(response.data){
                id                      == id
                name                    == nameColor
                names                   != null
                names.size()            == sizeNames
                pokemon_species         != null
                pokemon_species.size()  == sizeSpecies
            }

        where:
            id  | nameColor | sizeNames | sizeSpecies
            '1' | 'black'   | 5         | 40
            '2' | 'blue'    | 5         | 145
            '3' | 'brown'   | 5         | 123
            '4' | 'gray'    | 5         | 76
            '5' | 'green'   | 5         | 87
    }

}
