package br.com.api.pokemon

import groovyx.net.http.RESTClient
import spock.lang.Specification

class SearchItemPocket extends Specification{

    RESTClient client = new RESTClient('http://pokeapi.co/')

    def 'Consultar lista pocketItens'(){
        given:'Um recurso valido lista os pocket itens'
            def resource = '/api/v2/item-pocket/'
        when:'chamar o servico'
            def response = client.get(path: resource)
            println(response.data)

        then:'retorna a lista com sucesso'
            response.status == 200
            with(response.data){
                count == 8
                next == null
                previous == null
                results != null
                results.size()  == 8
                results[0].url  == 'https://pokeapi.co/api/v2/item-pocket/1/'
                results[0].name == 'misc'
                results[1].url  == 'https://pokeapi.co/api/v2/item-pocket/2/'
                results[1].name == 'medicine'
                results[2].url  == 'https://pokeapi.co/api/v2/item-pocket/3/'
                results[2].name == 'pokeballs'
                results[3].url  == 'https://pokeapi.co/api/v2/item-pocket/4/'
                results[3].name == 'machines'
                results[4].url  == 'https://pokeapi.co/api/v2/item-pocket/5/'
                results[4].name == 'berries'
                results[5].url  == 'https://pokeapi.co/api/v2/item-pocket/6/'
                results[5].name == 'mail'
                results[6].url  == 'https://pokeapi.co/api/v2/item-pocket/7/'
                results[6].name == 'battle'
                results[7].url  == 'https://pokeapi.co/api/v2/item-pocket/8/'
                results[7].name == 'key'
            }
    }
}
